package com.curso.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * 
 * @author sinensia
 *
 */

@Entity
@Table(name="curso")
public class Curso
{
	/**
	 * 
	 * @param codcurso sera la primary key de la bd
	 * @param nombre nombre del curso
	 * @param duracion del curso
	 * @param precio del curso 
	 */
	@Id
	private int codcurso;
	private String nombre;
	private int duracion;
	private double precio;
	
	/**
	 * Constructor vacio
	 */
	public Curso(){}

	/**
	 * Constructor con todos los parametros
	 */
	public Curso(int codcurso, String nombre, int duracion, double precio) 
	{
		super();
		this.codcurso = codcurso;
		this.nombre = nombre;
		this.duracion = duracion;
		this.precio = precio;
	}

	/**
	 * Getters y Setters de los atributos
	 * @return
	 */
	public int getCodcurso() {
		return codcurso;
	}
	public void setCodcurso(int codcurso) {
		this.codcurso = codcurso;
	}

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public int getDuracion() {
		return duracion;
	}
	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	/**
	 * ToString para que salga por pantalla 
	 */
	@Override
	public String toString() 
	{
		return "Curso [codcurso=" + codcurso + ", nombre=" + nombre + ", duracion=" + duracion + ", precio=" + precio;
	}
}
