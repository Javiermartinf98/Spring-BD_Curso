package com.curso.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.dao.CursoDao;
import com.curso.model.Curso;

/**
 * 
 * @author sinensia
 *
 */
@Service
public class CursoImpl implements CursoService
{
	@Autowired
	CursoDao dao;
	
	@Override
	public List<Curso> AltaCurso(Curso c) 
	{
		dao.save(c);
		return dao.findAll();
	}

	@Override
	public List<Curso> EliminarCurso(int codcurso)
	{
		dao.deleteById(codcurso);
		return dao.findAll();
	}

	@Override
	public void actualizarCurso(int codcurso, int duracion)
	{
		dao.actualizarCurso(codcurso, duracion);
	}

	@Override
	public List<Curso> cursos() 
	{
		return dao.findAll();
	}

	@Override
	public List<Curso> cursosXPrecios(double min, double max) 
	{
		return dao.cursosXPrecios(min, max);
	}

}
