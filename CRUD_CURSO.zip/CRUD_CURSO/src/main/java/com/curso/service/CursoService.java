package com.curso.service;

import java.util.List;

import com.curso.model.Curso;

/**
 * 
 * @author sinensia
 *
 */
public interface CursoService
{
	/**
	 * Metodos de la interfaz que tendremos que desarrollar en el Implements
	 * @param c en este metodo se pide dar de alta un curso y los liste
	 * @return
	 */
	List<Curso> AltaCurso(Curso c);
	
	/**
	 * En este metodo se pide eliminar un curso a traves del codcurso y los liste
	 * @param codcurso
	 * @return
	 */
	List<Curso> EliminarCurso(int codcurso);
	
	/**
	 * Aqui se pide modificar la duracion del curso a traves dl codcurso
	 * @param codcurso
	 * @param duracion
	 */
	void actualizarCurso(int codcurso,int duracion);
	
	/**
	 * Lista todos los cursos 
	 * @return
	 */
	List<Curso> cursos();
	
	/**
	 * Lista los cursos cuyos precios rondan el min y el max
	 * @param min
	 * @param max
	 * @return
	 */
	List<Curso> cursosXPrecios(double min, double max);
}
