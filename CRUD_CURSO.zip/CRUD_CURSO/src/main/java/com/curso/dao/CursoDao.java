package com.curso.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.curso.model.Curso;

/**
 * 
 * @author sinensia
 *
 */
public interface CursoDao extends JpaRepository<Curso, Integer>
{
	/**
	 * Query para conseguir listado de los cursos cuyo precios rondan x numeros
	 * @param min precio min
	 * @param max precio max
	 * @return
	 */
	@Query(value="SELECT * FROM cursos.curso where precio BETWEEN ? AND ?",  nativeQuery = true)
	List<Curso> cursosXPrecios(double min, double max);
	
	/**
	 * Query para modificar la duracion de un curso a traves de su codcurso
	 * @param codcurso primary key de la bd
	 * @param duracion que habra que modificar
	 */
	@Query(value="UPDATE cursos.curso SET duracion = ? where codcurso = ?",nativeQuery = true)
	void actualizarCurso(int codcurso,int duracion);
}
